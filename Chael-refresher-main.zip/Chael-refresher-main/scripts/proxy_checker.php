#!/usr/bin/env php
<?php
declare(strict_types=1);

namespace Langgor\Refresher;

require_once __DIR__ . '/../server/Config.php';
require_once __DIR__ . '/../server/ProxyManager.php';
require_once __DIR__ . '/../server/ProxyChecker.php';

Config::load();

$isCli = (php_sapi_name() === 'cli');
$timestamp = date('Y-m-d H:i:s');

echo "[$timestamp] === Memulai Langgor Proxy Scraper & Checker ===\n";

$onProgress = function(string $type, array $data) use ($isCli): void {
    if ($type === 'status') {
        echo "  [*] " . ($data['message'] ?? '') . "\n";
    } elseif ($type === 'batch_complete') {
        $percent = round(($data['processed'] / max(1, $data['total'])) * 100, 1);
        $alive = $data['alive_count'];
        $dead = $data['dead_count'];
        $batch = $data['batch'];
        $totalBatches = $data['total_batches'];
        echo "  [Batch {$batch}/{$totalBatches}] Progress: {$percent}% ({$data['processed']}/{$data['total']}) | Hidup: {$alive} | Mati: {$dead}\n";
    } elseif ($type === 'done') {
        echo "\n=== Rangkuman Hasil Pengecekan ===\n";
        echo "  Total Diunduh : {$data['total_scraped']}\n";
        echo "  Total Hidup   : {$data['total_alive']}\n";
        echo "  Rate Limited  : {$data['total_rate_limited']}\n";
        echo "  Total Mati    : {$data['total_dead']}\n";
        echo "  Tercepat      : " . ($data['fastest_latency_ms'] !== null ? "{$data['fastest_latency_ms']} ms" : "N/A") . "\n";
        echo "  Median        : " . ($data['median_latency_ms'] !== null ? "{$data['median_latency_ms']} ms" : "N/A") . "\n";
        echo "  Durasi Waktu  : {$data['duration_seconds']} detik\n";

        if (!empty($data['top_proxies'])) {
            echo "\nTop 10 Proxy Tercepat (HTTP/SOCKS4/SOCKS5):\n";
            echo str_repeat('-', 55) . "\n";
            printf("%-6s | %-35s | %-10s\n", "No", "Proxy", "Latensi");
            echo str_repeat('-', 55) . "\n";
            $rank = 1;
            foreach (array_slice($data['top_proxies'], 0, 10) as $tp) {
                printf("%-6d | %-35s | %-10s\n", $rank++, $tp['proxy'], $tp['latency_ms'] . " ms");
            }
            echo str_repeat('-', 55) . "\n";
        }
        echo "File proxies.txt & server/proxy_cache.json berhasil diperbarui!\n";
    }
};

try {
    $stats = ProxyChecker::run($onProgress);
    echo "[$timestamp] Selesai dengan sukses.\n";
    exit(0);
} catch (\Throwable $e) {
    echo "[$timestamp] ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
