<?php
declare(strict_types=1);

/**
 * Langgor · Cookie Refresher
 * Production Application & API Gateway
 */

// If GET request, serve health check or React SPA
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['health']) || (isset($_GET['action']) && $_GET['action'] === 'health')) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status' => 'healthy',
            'service' => 'Langgor Cookie Refresher',
            'version' => '2.0.0',
            'timestamp' => date('c')
        ]);
        exit;
    }

    $spaEntry = __DIR__ . '/index.html';
    if (file_exists($spaEntry)) {
        header('Content-Type: text/html; charset=UTF-8');
        header('X-Frame-Options: SAMEORIGIN');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        readfile($spaEntry);
        exit;
    }
}

// Delegate API requests (POST refresh) to API controller
require_once __DIR__ . '/api/index.php';
