import React from 'react';
import { CheckCircle2, AlertCircle, AlertTriangle, Info, X } from 'lucide-react';
import { ToastMessage } from '../types';

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2.5 max-w-[90vw] w-[420px] pointer-events-none">
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';
        const isWarning = toast.type === 'warning';

        return (
          <div
            key={toast.id}
            className="pointer-events-auto flex items-center justify-between gap-3 px-4 py-3 rounded-2xl bg-[#1C1C22]/90 backdrop-blur-2xl border border-white/10 shadow-[0_20px_40px_rgba(0,0,0,0.6)] animate-appear transition-all"
          >
            <div className="flex items-center gap-3 min-w-0">
              {isSuccess && <CheckCircle2 className="w-5 h-5 text-[#30D158] shrink-0" />}
              {isError && <AlertCircle className="w-5 h-5 text-[#FF453A] shrink-0" />}
              {isWarning && <AlertTriangle className="w-5 h-5 text-[#FF9F0A] shrink-0" />}
              {!isSuccess && !isError && !isWarning && <Info className="w-5 h-5 text-[#0A84FF] shrink-0" />}

              <div className="min-w-0 flex flex-col">
                <span className="text-[13px] font-semibold text-white tracking-tight truncate">
                  {toast.title}
                </span>
                {toast.message && (
                  <span className="text-[12px] text-white/60 truncate">
                    {toast.message}
                  </span>
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={() => onDismiss(toast.id)}
              className="p-1 rounded-full text-white/40 hover:text-white hover:bg-white/10 transition-colors shrink-0"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
