import React from 'react';
import { AmbientBackground } from '../AmbientBackground';

interface AppShellProps {
  children: React.ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({ children }) => {
  return (
    <div className="relative min-h-[100dvh] w-full flex flex-col items-center justify-start bg-[#070709] text-white selection:bg-[#0A84FF]/30 selection:text-white pt-[max(1.5rem,env(safe-area-inset-top))] pb-[max(1.5rem,env(safe-area-inset-bottom))] px-[max(1rem,env(safe-area-inset-left))] pr-[max(1rem,env(safe-area-inset-right))]">
      {/* Apple Ambient Mesh Lighting */}
      <AmbientBackground />

      {/* Main Content Area */}
      <main className="w-full max-w-[620px] my-auto flex flex-col items-center relative z-10 animate-appear">
        {children}
      </main>
    </div>
  );
};
