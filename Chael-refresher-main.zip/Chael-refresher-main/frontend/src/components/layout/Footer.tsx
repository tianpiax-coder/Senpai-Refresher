import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-8 mb-4 text-center text-white/40 text-[12px] leading-relaxed shrink-0 max-w-md mx-auto px-4">
      <p className="mb-2">
        © {new Date().getFullYear()} Langgor. All rights reserved.
      </p>
      <p className="text-[11px] text-white/30 mb-3">
        Tidak terafiliasi dengan Roblox Corporation.
      </p>
      <div className="flex items-center justify-center text-white/40 text-[11.5px]">
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="hover:text-white transition-colors outline-none bg-transparent"
        >
          Kembali ke atas
        </button>
      </div>
    </footer>
  );
};
