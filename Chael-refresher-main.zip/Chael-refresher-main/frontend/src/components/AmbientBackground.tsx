import React from 'react';

export const AmbientBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
      {/* Top Ambient Glow */}
      <div 
        className="absolute w-[clamp(300px,50vw,560px)] h-[clamp(300px,50vw,560px)] -top-[140px] left-1/2 -translate-x-1/2 rounded-full blur-[110px] opacity-45 pointer-events-none animate-float-1"
        style={{
          background: 'radial-gradient(circle, rgba(10, 132, 255, 0.25) 0%, rgba(120, 119, 198, 0.16) 50%, transparent 70%)'
        }}
      />
      {/* Bottom Ambient Glow */}
      <div 
        className="absolute w-[clamp(280px,45vw,500px)] h-[clamp(280px,45vw,500px)] -bottom-[130px] left-1/2 -translate-x-[40%] rounded-full blur-[110px] opacity-45 pointer-events-none animate-float-2"
        style={{
          background: 'radial-gradient(circle, rgba(94, 92, 230, 0.18) 0%, rgba(48, 209, 88, 0.1) 50%, transparent 70%)'
        }}
      />
    </div>
  );
};
