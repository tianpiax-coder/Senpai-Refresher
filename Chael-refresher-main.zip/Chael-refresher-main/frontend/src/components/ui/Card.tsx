import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  as?: 'div' | 'section' | 'article';
}

export const Card: React.FC<CardProps> = ({
  children,
  as: Component = 'div',
  className = '',
  ...props
}) => {
  return (
    <Component
      {...props}
      className={`w-full rounded-[24px] sm:rounded-[28px] bg-[rgba(22,22,28,0.72)] backdrop-blur-[36px] border border-white/[0.08] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.65),inset_0_1px_0_0_rgba(255,255,255,0.12)] p-[clamp(1.25rem,4.5vw,2.25rem)] relative overflow-hidden transition-all duration-300 ${className}`}
    >
      {children}
    </Component>
  );
};
