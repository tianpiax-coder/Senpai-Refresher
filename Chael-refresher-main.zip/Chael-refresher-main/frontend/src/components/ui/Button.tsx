import React from 'react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  leftIcon,
  rightIcon,
  disabled,
  className = '',
  ...props
}) => {
  const baseStyles =
    'relative inline-flex items-center justify-center font-medium rounded-xl transition-all duration-200 outline-none select-none disabled:opacity-45 disabled:pointer-events-none active:scale-[0.985]';

  const sizeStyles = {
    sm: 'text-[12.5px] px-3 py-1.5 gap-1.5',
    md: 'text-[14px] px-4 py-2.5 gap-2',
    lg: 'text-[15px] px-5 py-3 gap-2.5'
  }[size];

  const variantStyles = {
    primary:
      'bg-gradient-to-b from-[#0A84FF] to-[#0066CC] hover:from-[#1E8FFF] hover:to-[#0A74DE] text-white shadow-[0_4px_14px_rgba(10,132,255,0.38),inset_0_0.5px_0.5px_rgba(255,255,255,0.35)] border border-[#0A84FF]/40',
    secondary:
      'bg-white/[0.08] hover:bg-white/[0.13] text-white border border-white/15 backdrop-blur-xl shadow-sm',
    ghost:
      'bg-transparent hover:bg-white/[0.06] text-white/70 hover:text-white',
    danger:
      'bg-gradient-to-b from-[#FF453A] to-[#D73328] hover:from-[#FF5B52] hover:to-[#C62B21] text-white shadow-[0_4px_14px_rgba(255,69,58,0.35)]'
  }[variant];

  return (
    <button
      {...props}
      disabled={disabled || isLoading}
      className={`${baseStyles} ${sizeStyles} ${variantStyles} ${className}`}
    >
      {isLoading ? (
        <>
          <span
            className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin shrink-0"
            aria-hidden="true"
          />
          <span>{children}</span>
        </>
      ) : (
        <>
          {leftIcon && <span className="shrink-0">{leftIcon}</span>}
          <span>{children}</span>
          {rightIcon && <span className="shrink-0">{rightIcon}</span>}
        </>
      )}
    </button>
  );
};
