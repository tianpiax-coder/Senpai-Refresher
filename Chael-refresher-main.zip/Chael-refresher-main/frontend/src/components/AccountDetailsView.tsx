import React from 'react';
import { User, CheckCircle2, ShieldCheck, Mail, Phone, Sparkles, Calendar, Users } from 'lucide-react';
import { AccountDetails } from '../types';

interface AccountDetailsViewProps {
  details: AccountDetails;
}

export const AccountDetailsView: React.FC<AccountDetailsViewProps> = ({ details }) => {
  return (
    <div className="mb-6">
      {/* Avatar Header */}
      {details.avatarUrl && (
        <div className="flex justify-center mb-5">
          <div className="relative group">
            <img
              src={details.avatarUrl}
              alt={details.username}
              className="w-20 h-20 rounded-full object-cover bg-[#16161C] ring-2 ring-white/15 shadow-[0_8px_24px_rgba(0,0,0,0.5)] transition-transform duration-300 group-hover:scale-105"
            />
            {details.premium && (
              <span 
                className="absolute bottom-0 right-0 p-1.5 rounded-full bg-[#FFD60A] text-black shadow-md ring-2 ring-[#16161C]"
                title="Premium Member"
              >
                <Sparkles className="w-3.5 h-3.5 fill-black" />
              </span>
            )}
          </div>
        </div>
      )}

      {/* iOS Grouped Info Card */}
      <div className="bg-white/[0.03] border border-white/[0.08] rounded-2xl p-1 divide-y divide-white/[0.06] overflow-hidden">
        <div className="flex justify-between items-center px-4 py-2.5 text-[13px] gap-3">
          <span className="text-white/50 flex items-center gap-2 shrink-0">
            <User className="w-3.5 h-3.5 text-white/40" /> Username
          </span>
          <span className="font-medium text-white truncate text-right">
            {details.username || 'N/A'}
          </span>
        </div>

        <div className="flex justify-between items-center px-4 py-2.5 text-[13px] gap-3">
          <span className="text-white/50 shrink-0">Display Name</span>
          <span className="font-medium text-white truncate text-right">
            {details.displayName || 'N/A'}
          </span>
        </div>

        <div className="flex justify-between items-center px-4 py-2.5 text-[13px] gap-3">
          <span className="text-white/50 flex items-center gap-2 shrink-0">
            <Users className="w-3.5 h-3.5 text-white/40" /> Age Group
          </span>
          <div className="flex items-center gap-2 text-right">
            <span className="font-medium text-white">{details.ageGroup || 'N/A'}</span>
            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${
              details.ageGroupChecked
                ? 'bg-[#30D158]/15 text-[#30D158] border border-[#30D158]/30'
                : 'bg-white/10 text-white/60'
            }`}>
              {details.ageGroupStatus || (details.ageGroupChecked ? 'Checked' : 'Unchecked')}
            </span>
          </div>
        </div>

        <div className="flex justify-between items-center px-4 py-2.5 text-[13px] gap-3">
          <span className="text-white/50 flex items-center gap-2 shrink-0">
            <Calendar className="w-3.5 h-3.5 text-white/40" /> Birthday
          </span>
          <div className="flex items-center gap-2 text-right">
            <span className="font-medium text-white">{details.birthday || 'N/A'}</span>
            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${
              details.birthdayVerified
                ? 'bg-[#30D158]/15 text-[#30D158] border border-[#30D158]/30'
                : 'bg-white/10 text-white/60'
            }`}>
              {details.birthdayStatus || (details.birthdayVerified ? 'Verified' : 'Non Verified')}
            </span>
          </div>
        </div>

        <div className="flex justify-between items-center px-4 py-2.5 text-[13px] gap-3">
          <span className="text-white/50 flex items-center gap-2 shrink-0">
            <Mail className="w-3.5 h-3.5 text-white/40" /> Email
          </span>
          <span className="font-medium text-white break-all text-right">
            {details.email || 'Not available'}
          </span>
        </div>

        <div className="flex justify-between items-center px-4 py-2.5 text-[13px] gap-3">
          <span className="text-white/50 shrink-0">Email Verified</span>
          <span className="text-right">
            {details.emailVerified ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#30D158]/15 text-[#30D158] border border-[#30D158]/30">
                <CheckCircle2 className="w-3 h-3" /> Verified
              </span>
            ) : (
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-white/10 text-white/60">
                No
              </span>
            )}
          </span>
        </div>

        <div className="flex justify-between items-center px-4 py-2.5 text-[13px] gap-3">
          <span className="text-white/50 flex items-center gap-2 shrink-0">
            <Phone className="w-3.5 h-3.5 text-white/40" /> Phone
          </span>
          <span className="font-medium text-white text-right">
            {details.phone || 'Not available'}
          </span>
        </div>

        <div className="flex justify-between items-center px-4 py-2.5 text-[13px] gap-3">
          <span className="text-white/50 flex items-center gap-2 shrink-0">
            <ShieldCheck className="w-3.5 h-3.5 text-white/40" /> 2SV Indicator
          </span>
          <span className="text-right">
            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${
              details.twoFactor && details.twoFactor !== 'None'
                ? 'bg-[#0A84FF]/15 text-[#0A84FF] border border-[#0A84FF]/30 font-semibold'
                : 'bg-white/10 text-white/60'
            }`}>
              {details.twoFactor || details.twoFA || 'None'}
            </span>
          </span>
        </div>

        <div className="flex justify-between items-center px-4 py-2.5 text-[13px] gap-3">
          <span className="text-white/50 shrink-0">Premium</span>
          <span className="text-right">
            {details.premium ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#FFD60A]/15 text-[#FFD60A] border border-[#FFD60A]/30">
                Active
              </span>
            ) : (
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-white/10 text-white/60">
                No
              </span>
            )}
          </span>
        </div>
      </div>
    </div>
  );
};
