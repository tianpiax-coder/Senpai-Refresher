import React, { useState } from 'react';
import { Transaction } from '../../types';
import { Receipt, ChevronLeft, ChevronRight, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface TransactionsSectionProps {
  transactions?: Transaction[];
}

const PAGE_SIZE = 10;

export const TransactionsSection: React.FC<TransactionsSectionProps> = ({ transactions = [] }) => {
  const [currentPage, setCurrentPage] = useState<number>(1);

  if (transactions.length === 0) {
    return (
      <div className="w-full">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider mb-2 ml-1">
          <Receipt className="w-3.5 h-3.5 text-[#30D158]" />
          <span>Transactions Log</span>
        </div>
        <div className="rounded-2xl bg-white/[0.02] border border-white/5 p-4 text-center text-white/40 text-[12px]">
          No recent transactions recorded.
        </div>
      </div>
    );
  }

  const totalPages = Math.max(1, Math.ceil(transactions.length / PAGE_SIZE));
  const safePage = Math.min(currentPage, totalPages);
  const startIdx = (safePage - 1) * PAGE_SIZE;
  const currentTransactions = transactions.slice(startIdx, startIdx + PAGE_SIZE);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-2 ml-1">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider">
          <Receipt className="w-3.5 h-3.5 text-[#30D158]" />
          <span>Transactions Log ({transactions.length})</span>
        </div>

        <span className="text-[11.5px] text-white/40">
          Page {safePage} of {totalPages}
        </span>
      </div>

      {/* Transaction List */}
      <div className="flex flex-col gap-1.5 mb-3">
        {currentTransactions.map((tx, idx) => {
          const isIncome = tx.income;
          const thumb = tx.gameIcon || tx.creatorAvatar || tx.thumbnail;

          return (
            <div
              key={idx}
              className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.03] border border-white/10 hover:bg-white/[0.05] transition-colors"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-lg bg-black/40 overflow-hidden shrink-0 flex items-center justify-center border border-white/5">
                  {thumb ? (
                    <img src={thumb} alt="" loading="lazy" className="w-full h-full object-cover" />
                  ) : isIncome ? (
                    <ArrowUpRight className="w-4 h-4 text-[#30D158]" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4 text-[#FF453A]" />
                  )}
                </div>

                <div className="flex flex-col min-w-0">
                  <span className="text-[13px] font-medium text-white truncate max-w-[200px] sm:max-w-xs" title={tx.detail || tx.type}>
                    {tx.detail || tx.type}
                  </span>
                  <div className="flex items-center gap-2 text-[11px] text-white/40">
                    <span>{tx.type}</span>
                    {tx.date && (
                      <>
                        <span>·</span>
                        <span>{new Date(tx.date).toLocaleDateString()}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <span
                className={`text-[13.5px] font-bold shrink-0 ml-2 ${
                  isIncome ? 'text-[#30D158]' : 'text-[#FF453A]'
                }`}
              >
                {isIncome ? '+' : '-'}{tx.amount} R$
              </span>
            </div>
          );
        })}
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-1">
          <button
            type="button"
            disabled={safePage <= 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] disabled:opacity-30 disabled:pointer-events-none text-white text-[12px] font-medium transition-colors border border-white/10"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Previous</span>
          </button>

          <span className="text-[12px] text-white/50">
            {safePage} / {totalPages}
          </span>

          <button
            type="button"
            disabled={safePage >= totalPages}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] disabled:opacity-30 disabled:pointer-events-none text-white text-[12px] font-medium transition-colors border border-white/10"
          >
            <span>Next</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
