import React from 'react';
import { AccountDetails } from '../../types';
import { Coins, TrendingUp, TrendingDown, CreditCard, Calendar } from 'lucide-react';

interface EconomyOverviewProps {
  details: AccountDetails;
}

export const EconomyOverview: React.FC<EconomyOverviewProps> = ({ details }) => {
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };

  return (
    <div className="w-full flex flex-col gap-4 mb-6">
      {/* Economy Details Table */}
      <div>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider mb-2 ml-1">
          <Coins className="w-3.5 h-3.5 text-[#FFD60A]" />
          <span>Economy & Balances</span>
        </div>

        <div className="w-full rounded-2xl bg-white/[0.03] border border-white/10 px-3.5 py-1">
          <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
            <span className="text-white/60 font-normal">Robux Balance</span>
            <span className="text-[#FFD60A] font-bold drop-shadow-[0_0_8px_rgba(255,214,10,0.3)]">
              {formatNumber(details.robux)} R$
            </span>
          </div>

          <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
            <span className="text-white/60 font-normal">Pending Robux</span>
            <span className="text-white font-medium">
              {formatNumber(details.pendingRobux)} R$
            </span>
          </div>

          <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
            <span className="text-white/60 font-normal">RAP Total</span>
            <span className="text-[#FFD60A] font-semibold">
              {formatNumber(details.totalRAP)} R$
            </span>
          </div>

          <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
            <span className="text-white/60 font-normal flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-white/40" />
              <span>Account Credit</span>
            </span>
            <span className="text-white font-medium">
              {details.accountCredit !== null && details.accountCredit !== undefined
                ? `${details.accountCredit} Credits`
                : 'N/A'}
            </span>
          </div>

          <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
            <span className="text-white/60 font-normal">Incoming (Year)</span>
            <span className="text-[#30D158] font-semibold">
              +{formatNumber(details.incomingYear)} R$
            </span>
          </div>

          <div className="flex items-center justify-between py-2.5 text-[13.5px]">
            <span className="text-white/60 font-normal">Outgoing (Year)</span>
            <span className="text-[#FF453A] font-semibold">
              -{formatNumber(details.outgoingYear)} R$
            </span>
          </div>
        </div>
      </div>

      {/* Yearly Summary Bento Grid */}
      {details.yearlyTotals && Object.keys(details.yearlyTotals).length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider mb-2 ml-1">
            <Calendar className="w-3.5 h-3.5 text-[#BF5AF2]" />
            <span>Yearly Breakdown</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {Object.entries(details.yearlyTotals).map(([key, val]) => {
              if (typeof val !== 'number') return null;
              const k = key.toLowerCase();
              const isOut = k.includes('out') || k.includes('cost') || k.includes('spend') || k.includes('purchase');
              const isIn = k.includes('in') || k.includes('income') || k.includes('sale') || k.includes('stipend');
              const formattedLabel = key.replace(/([A-Z])/g, ' $1').replace(/^./, (s) => s.toUpperCase());

              return (
                <div
                  key={key}
                  className="rounded-xl bg-white/[0.03] border border-white/10 p-2.5 text-center flex flex-col justify-between hover:bg-white/[0.06] transition-colors"
                >
                  <span className="text-[10.5px] uppercase tracking-wider text-white/40 mb-1 line-clamp-1">
                    {formattedLabel}
                  </span>
                  <span
                    className={`text-[14px] font-bold tracking-tight ${
                      isOut ? 'text-[#FF453A]' : isIn ? 'text-[#30D158]' : 'text-white'
                    }`}
                  >
                    {isOut ? '-' : isIn ? '+' : ''}{formatNumber(val)} R$
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Overall Totals Bento Grid */}
      <div>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider mb-2 ml-1">
          <TrendingUp className="w-3.5 h-3.5 text-[#30D158]" />
          <span>Lifetime Totals</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-2xl bg-white/[0.03] border border-white/10 p-3.5 text-center flex flex-col items-center">
            <span className="text-[11px] uppercase tracking-wider text-white/40 mb-1 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-[#30D158]" />
              <span>Total Income</span>
            </span>
            <span className="text-[17px] font-bold text-[#30D158] tracking-tight">
              +{formatNumber(details.totalIncome)} R$
            </span>
          </div>

          <div className="rounded-2xl bg-white/[0.03] border border-white/10 p-3.5 text-center flex flex-col items-center">
            <span className="text-[11px] uppercase tracking-wider text-white/40 mb-1 flex items-center gap-1">
              <TrendingDown className="w-3.5 h-3.5 text-[#FF453A]" />
              <span>Total Outgoing</span>
            </span>
            <span className="text-[17px] font-bold text-[#FF453A] tracking-tight">
              -{formatNumber(details.totalOutgoing)} R$
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
