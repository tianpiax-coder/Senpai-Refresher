import React, { useState } from 'react';
import { Copy, Check, Eye, EyeOff } from 'lucide-react';
import { useClipboard } from '../../hooks/useClipboard';

interface CookieOutputProps {
  cookie: string;
  onCopySuccess?: () => void;
}

export const CookieOutput: React.FC<CookieOutputProps> = ({ cookie, onCopySuccess }) => {
  const [isMasked, setIsMasked] = useState<boolean>(true);
  const { hasCopied, copy } = useClipboard(2000);

  if (!cookie) return null;

  const handleCopy = async () => {
    const success = await copy(cookie);
    if (success && onCopySuccess) {
      onCopySuccess();
    }
  };

  return (
    <div className="flex flex-col gap-1.5 mt-5 w-full animate-appear">
      <div className="flex items-center justify-between">
        <label
          htmlFor="refreshed-cookie-output"
          className="text-[13px] font-semibold text-[#30D158] tracking-tight flex items-center gap-1.5"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#30D158] shadow-[0_0_8px_#30D158]" />
          <span>Cookie Baru</span>
        </label>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setIsMasked(!isMasked)}
            className="p-1 text-white/50 hover:text-white transition-colors rounded-md text-[11px] flex items-center gap-1 outline-none"
            title={isMasked ? 'Tampilkan karakter' : 'Sembunyikan karakter'}
          >
            {isMasked ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isMasked ? 'Lihat' : 'Tutup'}</span>
          </button>
        </div>
      </div>

      <div className="relative w-full">
        <textarea
          id="refreshed-cookie-output"
          rows={3}
          readOnly
          value={cookie}
          className={`w-full rounded-2xl bg-black/50 border border-[#30D158]/30 focus:border-[#30D158] text-white/90 text-[13px] font-mono leading-relaxed p-3.5 outline-none resize-none shadow-[0_0_20px_rgba(48,209,88,0.1)] ${
            isMasked ? 'text-security-disc' : ''
          }`}
          style={isMasked ? ({ WebkitTextSecurity: 'disc' } as React.CSSProperties) : {}}
        />
      </div>

      <button
        type="button"
        onClick={handleCopy}
        className={`w-full mt-2 py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 text-[14px] font-medium transition-all duration-200 outline-none ${
          hasCopied
            ? 'bg-[#30D158]/20 border border-[#30D158]/40 text-[#30D158] shadow-[0_4px_12px_rgba(48,209,88,0.25)]'
            : 'bg-white/[0.08] hover:bg-white/[0.13] text-white border border-white/15'
        }`}
      >
        {hasCopied ? (
          <>
            <Check className="w-4 h-4 text-[#30D158]" />
            <span className="font-semibold text-[#30D158]">Berhasil disalin!</span>
          </>
        ) : (
          <>
            <Copy className="w-4 h-4" />
            <span>Salin Cookie Baru</span>
          </>
        )}
      </button>
    </div>
  );
};
