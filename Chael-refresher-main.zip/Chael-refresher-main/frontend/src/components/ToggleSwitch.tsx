import React from 'react';

interface ToggleSwitchProps {
  id: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  disabled?: boolean;
}

export const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ id, checked, onChange, label, disabled }) => {
  return (
    <div className="flex items-center gap-3 my-4 cursor-pointer select-none">
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        id={id}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`w-11 h-[26px] rounded-full p-[2px] transition-colors duration-300 ease-in-out shrink-0 relative outline-none focus-visible:ring-2 focus-visible:ring-[#0A84FF] border ${
          checked ? 'bg-[#30D158] border-[#30D158]' : 'bg-[rgba(120,120,128,0.32)] border-white/10'
        } ${disabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`}
      >
        <span
          className={`block w-5 h-5 rounded-full bg-white shadow-[0_2px_5px_rgba(0,0,0,0.35)] transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${
            checked ? 'translate-x-[18px]' : 'translate-x-0'
          }`}
        />
      </button>

      <label
        htmlFor={id}
        onClick={() => !disabled && onChange(!checked)}
        className={`text-[13.5px] leading-snug cursor-pointer transition-colors ${
          disabled ? 'text-white/40 cursor-not-allowed' : 'text-white/80 hover:text-white'
        }`}
      >
        {label}
      </label>
    </div>
  );
};
