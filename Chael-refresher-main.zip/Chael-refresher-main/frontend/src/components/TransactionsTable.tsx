import React, { useState } from 'react';
import { Receipt, ChevronLeft, ChevronRight } from 'lucide-react';
import { Transaction } from '../types';

interface TransactionsTableProps {
  transactions: Transaction[];
  pageSize?: number;
}

export const TransactionsTable: React.FC<TransactionsTableProps> = ({ transactions, pageSize = 8 }) => {
  const [currentPage, setCurrentPage] = useState(1);

  if (!transactions || transactions.length === 0) return null;

  const totalPages = Math.max(1, Math.ceil(transactions.length / pageSize));
  const validPage = Math.min(Math.max(1, currentPage), totalPages);

  const startIdx = (validPage - 1) * pageSize;
  const currentItems = transactions.slice(startIdx, startIdx + pageSize);

  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 text-[11px] font-semibold text-white/50 tracking-[0.08em] uppercase mb-3 px-1">
        <Receipt className="w-3.5 h-3.5 text-[#30D158]" />
        <span>Recent Transactions Log</span>
      </div>

      <div className="bg-white/[0.03] border border-white/[0.08] rounded-2xl overflow-hidden divide-y divide-white/[0.05]">
        {currentItems.map((tx, idx) => {
          const thumb = tx.thumbnail || tx.creatorAvatar || tx.gameIcon;
          const isIncome = tx.income;

          return (
            <div
              key={`${tx.date}_${idx}`}
              className="flex items-center gap-3 px-3.5 py-2.5 hover:bg-white/[0.03] transition-colors min-w-0"
            >
              {thumb ? (
                <img
                  src={thumb}
                  alt={tx.name || tx.type}
                  className="w-9 h-9 rounded-lg object-cover bg-white/5 shrink-0"
                  loading="lazy"
                />
              ) : (
                <div className="w-9 h-9 rounded-lg bg-white/5 shrink-0 flex items-center justify-center text-white/30 text-[10px]">
                  R$
                </div>
              )}

              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-medium text-white truncate">
                  {tx.detail || tx.type || 'Transaction'}
                </div>
                <div className="text-[11px] text-white/40 truncate">
                  {tx.type} {tx.date ? `· ${new Date(tx.date).toLocaleDateString()}` : ''}
                </div>
              </div>

              <div className={`text-[13px] font-semibold shrink-0 ml-2 ${
                isIncome ? 'text-[#30D158]' : 'text-[#FF453A]'
              }`}>
                {isIncome ? `+${tx.amount}` : `-${tx.amount}`} R$
              </div>
            </div>
          );
        })}
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 mt-3">
          <button
            type="button"
            disabled={validPage <= 1}
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white/[0.05] border border-white/10 text-white/70 text-[12px] font-medium hover:bg-white/[0.1] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <ChevronLeft className="w-3.5 h-3.5" /> Prev
          </button>

          <span className="text-[12px] text-white/40 font-medium">
            Page {validPage} of {totalPages}
          </span>

          <button
            type="button"
            disabled={validPage >= totalPages}
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white/[0.05] border border-white/10 text-white/70 text-[12px] font-medium hover:bg-white/[0.1] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            Next <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
