import React from 'react';
import { FlaskConical } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="flex flex-col items-center mb-6 shrink-0">
      <h1 className="text-[clamp(2.2rem,6vw,2.75rem)] font-bold tracking-[-0.035em] leading-tight text-center bg-gradient-to-b from-white via-white/90 to-white/60 bg-clip-text text-transparent mb-1">
        Langgor<span className="text-[#0A84FF] drop-shadow-[0_0_16px_rgba(10,132,255,0.45)]">.</span>
      </h1>
      <div className="text-[12px] font-normal text-white/50 text-center mb-4">
        Roblox Cookie Refresher
      </div>
      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.04] border border-white/10 backdrop-blur-xl transition-all hover:bg-white/[0.06]">
        <span className="w-1.5 h-1.5 rounded-full bg-[#FF9F0A] shadow-[0_0_8px_#FF9F0A] animate-pulse-subtle" />
        <FlaskConical className="w-3.5 h-3.5 text-[#FF9F0A]" />
        <span className="text-[11.5px] text-white/70">
          Versi beta
        </span>
      </div>
    </header>
  );
};
