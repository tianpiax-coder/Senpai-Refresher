import React from 'react';
import { AppShell } from './components/layout/AppShell';
import { Header } from './components/Header';
import { Footer } from './components/layout/Footer';
import { RefresherCard } from './components/features/RefresherCard';
import { ToastContainer } from './components/ToastContainer';
import { useToast } from './hooks/useToast';

export const App: React.FC = () => {
  const { toasts, showToast, dismissToast } = useToast();

  return (
    <AppShell>
      <Header />
      <RefresherCard onNotify={showToast} />
      <Footer />
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </AppShell>
  );
};

export default App;
