/**
 * Cookie validation and sanitization utility.
 * Never logs or exposes cookie contents to console or storage.
 */

export interface ValidationResult {
  isValid: boolean;
  sanitizedCookie: string;
  errorMessage?: string;
}

export function sanitizeCookie(raw: string): string {
  let cleaned = raw.trim();

  // 1. JSON export support (e.g. from Cookie-Editor / EditThisCookie)
  if (cleaned.includes('{') || cleaned.includes('[')) {
    const jsonMatch = cleaned.match(/"value"\s*:\s*"([^"]+)"/i);
    if (jsonMatch && jsonMatch[1]) {
      cleaned = jsonMatch[1];
    }
  }

  // 2. Remove leading 'cookie:' case-insensitive
  cleaned = cleaned.replace(/^\s*cookie:\s*/i, '');

  // 3. URL decode if percent-encoded (e.g., %7C -> |)
  if (cleaned.toLowerCase().includes('%7c')) {
    try {
      cleaned = decodeURIComponent(cleaned);
    } catch {
      // ignore
    }
  }

  // 4. Strip internal whitespaces
  cleaned = cleaned.replace(/\s+/g, '');

  // 5. If contains WARNING pattern (even if missing leading _ or |), normalize and extract cleanly
  const warningMatch = cleaned.match(/(?:_|\|)*WARNING:-DO-NOT-SHARE-THIS[^;'"\s]+/i);
  if (warningMatch && warningMatch[0]) {
    return warningMatch[0].replace(/^(?:_|\|)*WARNING/i, '_|WARNING');
  }

  // 6. Look for .ROBLOSECURITY= or ROBLOSECURITY=
  const robloxMatch = cleaned.match(/\.?ROBLOSECURITY\s*=\s*([^;]+)/i);
  if (robloxMatch && robloxMatch[1]) {
    return robloxMatch[1].replace(/['"]+/g, '').trim();
  }

  // 7. Fallback: split by semicolon, strip quotes
  const parts = cleaned.split(';');
  return parts[0].replace(/['"]+/g, '').trim();
}

export function validateCookie(raw: string): ValidationResult {
  if (!raw || raw.trim().length === 0) {
    return {
      isValid: false,
      sanitizedCookie: '',
      errorMessage: 'Silakan masukkan cookie .ROBLOSECURITY Anda.'
    };
  }

  const sanitized = sanitizeCookie(raw);

  if (sanitized.length < 100) {
    return {
      isValid: false,
      sanitizedCookie: sanitized,
      errorMessage: 'Format cookie tidak valid: Karakter terlalu pendek. Cookie .ROBLOSECURITY yang valid memiliki panjang beberapa ratus karakter.'
    };
  }

  return {
    isValid: true,
    sanitizedCookie: sanitized
  };
}
