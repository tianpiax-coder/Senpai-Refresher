/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        apple: {
          bg: '#070709',
          surface: 'rgba(22, 22, 28, 0.72)',
          border: 'rgba(255, 255, 255, 0.08)',
          blue: '#0A84FF',
          green: '#30D158',
          yellow: '#FFD60A',
          orange: '#FF9F0A',
          red: '#FF453A',
          purple: '#BF5AF2'
        }
      },
      fontFamily: {
        sans: [
          '-apple-system',
          'BlinkMacSystemFont',
          '"SF Pro Text"',
          '"SF Pro Display"',
          'Inter',
          'system-ui',
          'sans-serif'
        ],
        mono: [
          'SF Mono',
          'Menlo',
          'Monaco',
          'Consolas',
          'monospace'
        ]
      },
      backdropBlur: {
        'apple': '40px'
      }
    },
  },
  plugins: [],
}
