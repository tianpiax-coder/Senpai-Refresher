<?php
declare(strict_types=1);

namespace Langgor\Refresher;

require_once __DIR__ . '/Config.php';
require_once __DIR__ . '/ProxyManager.php';

class ProxyChecker {
    public const DEFAULT_URL = 'https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=protocolipport&format=text';
    public const TARGET_TEST_URL = 'https://users.roblox.com/v1/users/authenticated';

    /**
     * Download and parse raw proxies from ProxyScrape.
     */
    public static function fetchRawProxies(?string $url = null): array {
        $sourceUrl = $url ?: (string)Config::get('PROXYSCRAPE_URL', self::DEFAULT_URL);

        $ch = curl_init($sourceUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
        ]);

        $body = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($httpCode !== 200 || !is_string($body) || strlen(trim($body)) === 0) {
            throw new \RuntimeException("Failed to fetch proxy list from source: HTTP $httpCode ($err)");
        }

        $lines = explode("\n", $body);
        $unique = [];

        foreach ($lines as $line) {
            $parsed = ProxyManager::parseProxyString(trim($line));
            if ($parsed !== null) {
                $key = $parsed['scheme'] . '://' . $parsed['host'] . ':' . $parsed['port'];
                if (!isset($unique[$key])) {
                    $unique[$key] = $parsed;
                }
            }
        }

        return array_values($unique);
    }

    /**
     * Concurrent health check against Roblox authentication endpoint.
     */
    public static function checkPool(
        array $proxies,
        int $concurrency = 50,
        float $timeout = 4.0,
        ?callable $onProgress = null
    ): array {
        $total = count($proxies);
        if ($total === 0) {
            return ['alive' => [], 'rate_limited' => [], 'dead' => []];
        }

        $alive = [];
        $rateLimited = [];
        $dead = [];

        $batches = array_chunk($proxies, max(1, $concurrency));
        $batchCount = count($batches);
        $processedCount = 0;

        foreach ($batches as $batchIdx => $batch) {
            $multi = curl_multi_init();
            if (defined('CURLMOPT_PIPELINING')) {
                curl_multi_setopt($multi, CURLMOPT_PIPELINING, CURLPIPE_MULTIPLEX);
            }

            $handles = [];
            foreach ($batch as $p) {
                $ch = curl_init(self::TARGET_TEST_URL);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HEADER => true,
                    CURLOPT_NOBODY => false,
                    CURLOPT_TIMEOUT => (int)ceil($timeout),
                    CURLOPT_CONNECTTIMEOUT => 2,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => false,
                    CURLOPT_PROXY => $p['host'],
                    CURLOPT_PROXYPORT => $p['port'],
                    CURLOPT_PROXYTYPE => $p['type'],
                    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
                    CURLOPT_HTTPHEADER => [
                        'Accept: application/json',
                        'Origin: https://www.roblox.com'
                    ]
                ]);

                if (!empty($p['user'])) {
                    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $p['user'] . ':' . ($p['pass'] ?? ''));
                }

                curl_multi_add_handle($multi, $ch);
                $handles[(int)$ch] = ['ch' => $ch, 'proxy' => $p];
            }

            $running = null;
            do {
                $status = curl_multi_exec($multi, $running);
                while ($info = curl_multi_info_read($multi)) {
                    $ch = $info['handle'];
                    $hId = (int)$ch;
                    if (!isset($handles[$hId])) {
                        continue;
                    }

                    $pData = $handles[$hId]['proxy'];
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $totalTime = curl_getinfo($ch, CURLINFO_TOTAL_TIME);
                    $latencyMs = round($totalTime * 1000, 1);
                    $content = curl_multi_getcontent($ch);

                    // Verification criteria:
                    // 401: Unauthorized (Normal Roblox response without cookie)
                    // 200: OK
                    // Cloudflare blocks (403 or HTML challenges) are strictly rejected as dead.
                    $isRobloxJson = is_string($content) && (str_contains($content, 'errors') || str_contains($content, 'Unauthorized') || str_contains($content, '"id"'));
                    $isCloudflareBlock = is_string($content) && (str_contains($content, '<html') || str_contains($content, 'Cloudflare') || str_contains($content, 'cf-ray') || str_contains($content, 'Just a moment...'));

                    if (($httpCode === 401 || $httpCode === 200) && $isRobloxJson && !$isCloudflareBlock) {
                        $alive[] = array_merge($pData, [
                            'http_code' => $httpCode,
                            'latency_ms' => $latencyMs,
                            'status' => 'alive'
                        ]);
                    } elseif ($httpCode === 429) {
                        $rateLimited[] = array_merge($pData, [
                            'http_code' => 429,
                            'latency_ms' => $latencyMs,
                            'status' => 'rate_limited'
                        ]);
                    } else {
                        $dead[] = array_merge($pData, [
                            'http_code' => $httpCode,
                            'latency_ms' => $latencyMs,
                            'status' => 'dead',
                            'error' => curl_error($ch) ?: ($isCloudflareBlock ? 'Cloudflare Challenge/Block' : "HTTP $httpCode")
                        ]);
                    }
                }

                if ($running) {
                    if (curl_multi_select($multi, 0.05) === -1) {
                        usleep(1000);
                    }
                }
            } while ($running && $status === CURLM_OK);

            foreach ($handles as $item) {
                curl_multi_remove_handle($multi, $item['ch']);
                curl_close($item['ch']);
            }
            curl_multi_close($multi);

            $processedCount += count($batch);
            if ($onProgress) {
                call_user_func($onProgress, 'batch_complete', [
                    'batch' => $batchIdx + 1,
                    'total_batches' => $batchCount,
                    'processed' => $processedCount,
                    'total' => $total,
                    'alive_count' => count($alive),
                    'dead_count' => count($dead)
                ]);
            }
        }

        return [
            'alive' => $alive,
            'rate_limited' => $rateLimited,
            'dead' => $dead
        ];
    }

    /**
     * Sort alive proxies strictly ascending by latency, write to proxies.txt, and cache stats.
     */
    public static function sortAndSave(
        array $results,
        string $targetFile = __DIR__ . '/../proxies.txt',
        string $cacheFile = __DIR__ . '/proxy_cache.json'
    ): array {
        $alive = $results['alive'] ?? [];
        $rateLimited = $results['rate_limited'] ?? [];
        $dead = $results['dead'] ?? [];

        // Sort alive proxies ascending by latency (fastest first)
        usort($alive, fn($a, $b) => ($a['latency_ms'] <=> $b['latency_ms']));

        // Format proxy lines with scheme
        $lines = [];
        $lines[] = '# ==============================================================';
        $lines[] = '# Auto-generated by Langgor ProxyChecker';
        $lines[] = '# Source: ProxyScrape (HTTP, SOCKS4, SOCKS5)';
        $lines[] = '# Checked: ' . date('c');
        $lines[] = '# Total Scraped: ' . (count($alive) + count($rateLimited) + count($dead));
        $lines[] = '# Total Verified Alive: ' . count($alive);
        $lines[] = '# Sorted: Fastest latency (ms) ascending';
        $lines[] = '# ==============================================================';
        $lines[] = '';

        foreach ($alive as $p) {
            $cred = '';
            if (!empty($p['user'])) {
                $cred = $p['user'] . ':' . ($p['pass'] ?? '') . '@';
            }
            $line = "{$p['scheme']}://{$cred}{$p['host']}:{$p['port']}";
            $lines[] = $line;
        }

        @file_put_contents($targetFile, implode("\n", $lines) . "\n");

        // Compute latency metrics
        $fastest = !empty($alive) ? $alive[0]['latency_ms'] : null;
        $median = null;
        if (!empty($alive)) {
            $mid = (int)floor(count($alive) / 2);
            $median = $alive[$mid]['latency_ms'];
        }

        $topSample = array_map(function($p) {
            return [
                'proxy' => "{$p['scheme']}://{$p['host']}:{$p['port']}",
                'scheme' => $p['scheme'],
                'latency_ms' => $p['latency_ms']
            ];
        }, array_slice($alive, 0, 15));

        $cacheData = [
            'last_checked' => date('c'),
            'next_check' => date('c', time() + 3600),
            'total_scraped' => count($alive) + count($rateLimited) + count($dead),
            'total_alive' => count($alive),
            'total_rate_limited' => count($rateLimited),
            'total_dead' => count($dead),
            'fastest_latency_ms' => $fastest,
            'median_latency_ms' => $median,
            'top_proxies' => $topSample
        ];

        @file_put_contents($cacheFile, json_encode($cacheData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

        // Clean up expired cooldowns and reload ProxyManager to immediately pick up fresh sorted list
        ProxyManager::cleanupCooldowns();
        ProxyManager::reload();

        return $cacheData;
    }

    /**
     * Run full pipeline: Fetch -> Test -> Sort & Save.
     */
    public static function run(?callable $onProgress = null): array {
        $startTime = microtime(true);

        if ($onProgress) {
            call_user_func($onProgress, 'status', ['message' => 'Mengunduh daftar proxy dari ProxyScrape...']);
        }

        $rawProxies = self::fetchRawProxies();
        $totalRaw = count($rawProxies);

        if ($onProgress) {
            call_user_func($onProgress, 'status', [
                'message' => "Berhasil mengunduh {$totalRaw} proxy unik. Memulai pengetesan paralel (HTTP, SOCKS4, SOCKS5)..."
            ]);
        }

        $concurrency = (int)Config::get('PROXY_CHECK_CONCURRENCY', 50);
        $timeout = (float)Config::get('PROXY_CHECK_TIMEOUT', 4.0);

        $results = self::checkPool($rawProxies, $concurrency, $timeout, $onProgress);

        if ($onProgress) {
            call_user_func($onProgress, 'status', [
                'message' => 'Pengetesan selesai. Mengurutkan proxy hidup berdasarkan latensi tercepat...'
            ]);
        }

        $savedStats = self::sortAndSave($results);
        $savedStats['duration_seconds'] = round(microtime(true) - $startTime, 2);

        if ($onProgress) {
            call_user_func($onProgress, 'done', $savedStats);
        }

        return $savedStats;
    }
}
