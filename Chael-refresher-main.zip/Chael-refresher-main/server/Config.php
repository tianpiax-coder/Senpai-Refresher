<?php
declare(strict_types=1);

namespace Langgor\Refresher;

class Config {
    private static array $env = [];
    private static bool $loaded = false;

    public static function load(string $envPath = __DIR__ . '/../.env'): void {
        if (self::$loaded) {
            return;
        }

        if (file_exists($envPath)) {
            $lines = @file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (is_array($lines)) {
                foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || str_starts_with($line, '#')) {
                    continue;
                }
                if (str_contains($line, '=')) {
                    [$key, $value] = explode('=', $line, 2);
                    $key = trim($key);
                    $value = trim($value);
                    if (
                        (str_starts_with($value, '"') && str_ends_with($value, '"')) ||
                        (str_starts_with($value, "'") && str_ends_with($value, "'"))
                    ) {
                        $value = substr($value, 1, -1);
                    }
                    self::$env[$key] = $value;
                }
            }
        }
    }

        self::$loaded = true;

        // Apply error reporting
        if (self::get('APP_DEBUG', 'false') === 'true') {
            error_reporting(E_ALL);
            ini_set('display_errors', '1');
        } else {
            error_reporting(0);
            ini_set('display_errors', '0');
        }
    }

    public static function get(string $key, mixed $default = null): mixed {
        if (!self::$loaded) {
            self::load();
        }
        return self::$env[$key] ?? getenv($key) ?: $default;
    }

    public static function sendSecurityHeaders(): void {
        if (headers_sent()) {
            return;
        }
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    }
}
