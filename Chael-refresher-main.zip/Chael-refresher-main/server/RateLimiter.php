<?php
declare(strict_types=1);

namespace Langgor\Refresher;

class RateLimiter {
    public static function check(): bool {
        if (Config::get('RATE_LIMIT_ENABLED', 'true') !== 'true') {
            return true;
        }

        $ip = self::getClientIp();
        $window = (int)Config::get('RATE_LIMIT_WINDOW_SECONDS', 60);
        $maxRequests = (int)Config::get('RATE_LIMIT_MAX_REQUESTS', 20);

        $hash = hash('sha256', 'refresher_ip_' . $ip);
        $cacheFile = sys_get_temp_dir() . '/rate_' . $hash . '.json';
        $now = time();

        $fp = fopen($cacheFile, 'c+');
        if (!$fp) {
            return true; // Graceful degradation if unable to open file
        }

        flock($fp, LOCK_EX);
        $content = stream_get_contents($fp);
        $requests = $content ? json_decode($content, true) : [];
        if (!is_array($requests)) {
            $requests = [];
        }

        // Filter timestamps within current window
        $cutoff = $now - $window;
        $validRequests = array_filter($requests, fn($timestamp) => $timestamp > $cutoff);

        if (count($validRequests) >= $maxRequests) {
            flock($fp, LOCK_UN);
            fclose($fp);
            header('HTTP/1.1 429 Too Many Requests');
            header('Retry-After: ' . $window);
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Too many requests. Please slow down and try again shortly.',
                'rate_limited' => true
            ]);
            exit;
        }

        $validRequests[] = $now;
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode(array_values($validRequests)));
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);

        return true;
    }

    private static function getClientIp(): string {
        $headers = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
            'REMOTE_ADDR'
        ];

        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = explode(',', (string)$_SERVER[$header])[0];
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '127.0.0.1';
    }
}
